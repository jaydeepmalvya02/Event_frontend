import React from 'react'

const ShowContactInfo = () => {
  return (
    <div>ShowContactInfo</div>
  )
}

export default ShowContactInfo